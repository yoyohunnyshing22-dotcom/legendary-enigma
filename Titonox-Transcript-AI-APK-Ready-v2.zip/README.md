# Titonox Transcript AI

A mobile-friendly transcript + AI knowledge-book starter.

## Features
- Video/audio upload → Groq Whisper transcription
- Fast multilingual transcription
- Transcript editor
- Groq AI summary/explanation/notes/Q&A/custom task
- Books + chapters stored locally in SQLite
- Save AI answers into a selected book
- Browser text-to-speech
- Transcript history
- Optional custom OpenAI-compatible model configuration
- API key kept on the backend for the main Groq connection

## Run
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your Groq API key in `.env`.
4. Run:
   npm install
   npm start
5. Open http://localhost:3000

## Notes
Groq's current speech-to-text endpoint supports direct file uploads and models such as
`whisper-large-v3-turbo` and `whisper-large-v3`. File-size limits and account rate limits
still apply. For large files, add chunking in a production build.

The app intentionally uses user-provided video/audio files. Automatic downloading of
arbitrary Instagram content should be implemented only through an authorized/public
source flow and according to Instagram's terms.

For production:
- add authentication
- use encrypted server-side key storage
- add rate limiting
- add object storage
- add background jobs for long videos
- add chunking for files above API limits
- add proper custom-provider adapters
