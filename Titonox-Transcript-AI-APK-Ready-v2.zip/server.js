import express from "express";
import multer from "multer";
import dotenv from "dotenv";
import Database from "better-sqlite3";
import Groq from "groq-sdk";
import fs from "fs";
import path from "path";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(process.cwd(), "uploads");
const dataDir = path.join(process.cwd(), "data");
fs.mkdirSync(uploadDir, { recursive: true });
fs.mkdirSync(dataDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 100 * 1024 * 1024 }
});

const db = new Database(path.join(dataDir, "titonox.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS chapters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS transcripts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  source TEXT DEFAULT '',
  language TEXT DEFAULT '',
  text TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const groq = process.env.GROQ_API_KEY ? new Groq({ apiKey: process.env.GROQ_API_KEY }) : null;

function requireGroq(res) {
  if (!groq) {
    res.status(503).json({ error: "Groq API is not configured. Add GROQ_API_KEY to .env." });
    return false;
  }
  return true;
}

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(process.cwd(), "public")));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, groqConfigured: !!groq });
});

app.get("/api/books", (req, res) => {
  const rows = db.prepare(`
    SELECT b.*, COUNT(c.id) AS chapter_count
    FROM books b LEFT JOIN chapters c ON c.book_id=b.id
    GROUP BY b.id ORDER BY b.updated_at DESC
  `).all();
  res.json(rows);
});

app.post("/api/books", (req, res) => {
  const title = String(req.body.title || "").trim();
  const description = String(req.body.description || "").trim();
  if (!title) return res.status(400).json({ error: "Book title required." });
  const info = db.prepare("INSERT INTO books(title,description) VALUES(?,?)").run(title, description);
  res.json(db.prepare("SELECT * FROM books WHERE id=?").get(info.lastInsertRowid));
});

app.get("/api/books/:id", (req, res) => {
  const book = db.prepare("SELECT * FROM books WHERE id=?").get(req.params.id);
  if (!book) return res.status(404).json({ error: "Book not found." });
  book.chapters = db.prepare("SELECT * FROM chapters WHERE book_id=? ORDER BY id").all(req.params.id);
  res.json(book);
});

app.post("/api/books/:id/chapters", (req, res) => {
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "").trim();
  if (!title || !content) return res.status(400).json({ error: "Title and content required." });
  const info = db.prepare("INSERT INTO chapters(book_id,title,content) VALUES(?,?,?)")
    .run(req.params.id, title, content);
  db.prepare("UPDATE books SET updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  res.json(db.prepare("SELECT * FROM chapters WHERE id=?").get(info.lastInsertRowid));
});

app.put("/api/chapters/:id", (req, res) => {
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "").trim();
  db.prepare("UPDATE chapters SET title=?, content=? WHERE id=?").run(title, content, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/chapters/:id", (req, res) => {
  db.prepare("DELETE FROM chapters WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.get("/api/transcripts", (req, res) => {
  res.json(db.prepare("SELECT * FROM transcripts ORDER BY id DESC LIMIT 100").all());
});

app.post("/api/transcribe", upload.single("file"), async (req, res) => {
  if (!requireGroq(res)) return;
  if (!req.file) return res.status(400).json({ error: "Video/audio file required." });

  try {
    const language = String(req.body.language || "").trim();
    const prompt = String(req.body.prompt || "").trim();
    const transcription = await groq.audio.transcriptions.create({
      file: fs.createReadStream(req.file.path),
      model: "whisper-large-v3-turbo",
      response_format: "verbose_json",
      timestamp_granularities: ["segment"],
      ...(language ? { language } : {}),
      ...(prompt ? { prompt } : {}),
      temperature: 0
    });

    const text = transcription.text || "";
    const title = String(req.body.title || req.file.originalname || "Untitled Transcript");
    const info = db.prepare("INSERT INTO transcripts(title,source,language,text) VALUES(?,?,?,?)")
      .run(title, String(req.body.source || ""), language, text);

    res.json({
      id: info.lastInsertRowid,
      title,
      text,
      language,
      segments: transcription.segments || []
    });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Transcription failed." });
  } finally {
    fs.promises.unlink(req.file.path).catch(() => {});
  }
});

app.post("/api/ai", async (req, res) => {
  if (!requireGroq(res)) return;
  const { transcript, instruction, model } = req.body;
  if (!transcript || !instruction) return res.status(400).json({ error: "Transcript and instruction required." });

  try {
    const completion = await groq.chat.completions.create({
      model: model || "llama-3.3-70b-versatile",
      temperature: 0.3,
      messages: [
        {
          role: "system",
          content: "You are Titonox Knowledge AI. Analyze the user's transcript faithfully. Do not invent facts. Use clear Hindi/Hinglish unless the user asks for another language."
        },
        { role: "user", content: `TRANSCRIPT:\n${transcript}\n\nTASK:\n${instruction}` }
      ]
    });
    res.json({ text: completion.choices?.[0]?.message?.content || "" });
  } catch (e) {
    res.status(500).json({ error: e?.message || "AI request failed." });
  }
});

app.post("/api/custom-ai", async (req, res) => {
  const { apiKey, baseURL, model, transcript, instruction } = req.body;
  if (!apiKey || !model || !transcript || !instruction) {
    return res.status(400).json({ error: "apiKey, model, transcript and instruction are required." });
  }
  try {
    const client = new Groq({ apiKey, ...(baseURL ? { baseURL } : {}) });
    const completion = await client.chat.completions.create({
      model,
      temperature: 0.3,
      messages: [
        { role: "system", content: "You are a helpful knowledge assistant. Be accurate and concise." },
        { role: "user", content: `TRANSCRIPT:\n${transcript}\n\nTASK:\n${instruction}` }
      ]
    });
    res.json({ text: completion.choices?.[0]?.message?.content || "" });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Custom model request failed." });
  }
});

app.listen(PORT, () => console.log(`Titonox Transcript AI running on http://localhost:${PORT}`));
