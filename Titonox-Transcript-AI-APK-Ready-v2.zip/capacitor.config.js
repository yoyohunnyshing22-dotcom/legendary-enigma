import { CapacitorConfig } from '@capacitor/cli';

const config = {
  appId: 'com.titonox.transcriptai',
  appName: 'Titonox Transcript AI',
  webDir: 'public',
  bundledWebRuntime: false
};

export default config;
